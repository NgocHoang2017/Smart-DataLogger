<?php
	// tạo cơ sở dữ liệu
	$con = mysqli_connect("localhost","root","","users"); //Kết nối database.
//	mysqli_set_charset($con,'utf8');
?>
