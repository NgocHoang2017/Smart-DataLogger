#pragma once

void example();